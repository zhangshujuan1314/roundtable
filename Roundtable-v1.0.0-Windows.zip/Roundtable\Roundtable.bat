@echo off
chcp 65001 >nul 2>&1
title Roundtable — 多模型圆桌决策

echo.
echo   ◉ Roundtable — 多模型圆桌决策
echo.

:: 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到 Python,请先安装 Python 3.10+
    echo 下载: https://www.python.org/downloads/
    pause
    exit /b 1
)

:: 检查依赖
python -c "import openai" >nul 2>&1
if errorlevel 1 (
    echo 正在安装依赖...
    pip install openai python-dotenv rich markdown --quiet
)

:: 检查 .env
if not exist ".env" (
    if exist ".env.example" copy .env.example .env >nul
    echo 请在 .env 文件中填入 API Key
    start notepad .env
    pause
)

:: 启动
echo 启动中...
start "" http://127.0.0.1:7800
python -m web.app --port 7800 --no-browser
